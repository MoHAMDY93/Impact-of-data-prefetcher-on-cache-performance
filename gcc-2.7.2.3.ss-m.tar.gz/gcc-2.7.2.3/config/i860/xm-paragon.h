/* Configuration for GCC for Intel i860 running OSF/1AD.  */

#include "i860/xm-i860.h"
#include "xm-svr3.h"
