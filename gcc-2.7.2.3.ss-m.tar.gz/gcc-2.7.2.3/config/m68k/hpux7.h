/* tm.h for m68k running HPUX version 7.  */

/* fletcher@cs.utexas.edu says this is needed.  */
#define NO_DOT_IN_LABEL
#define NO_BUGS

#include "m68k/hp320.h"
